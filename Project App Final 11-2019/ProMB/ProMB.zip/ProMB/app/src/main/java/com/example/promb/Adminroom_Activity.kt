package com.example.promb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Adminroom_Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adminroom_)
    }
}
